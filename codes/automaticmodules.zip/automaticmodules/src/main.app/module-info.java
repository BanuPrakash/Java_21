module main.app {
    requires common;
}