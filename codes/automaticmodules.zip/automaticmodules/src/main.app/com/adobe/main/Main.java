package com.adobe.main;
import com.adobe.util.SampleUtil;

public class Main {
    public static void main(String[] args) {
        System.out.println(SampleUtil.getDayOfMonth());
    }
}